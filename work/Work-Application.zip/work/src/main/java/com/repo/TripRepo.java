package com.example.work.repo;

import com.example.work.domain.Trip;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TripRepo extends JpaRepository<Trip , Long> {
}
