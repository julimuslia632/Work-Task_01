package com.example.work.service;

import com.example.work.domain.Flight;
import com.example.work.domain.Trip;
import java.util.List;

public interface UserService {
    Trip addTrip(Trip trip);
    void addTripToUser(String username,Long trip_id);
    List<Flight> getFlights();
    void addFlightToUser(String username, Long flight_id , Long trip_id);

}
